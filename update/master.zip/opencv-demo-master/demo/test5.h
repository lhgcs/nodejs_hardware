#ifndef TEST5_H
#define TEST5_H


void test5();

#endif // TEST5_H
