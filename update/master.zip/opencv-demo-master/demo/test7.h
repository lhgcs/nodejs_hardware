#ifndef TEST7_H
#define TEST7_H


void test7();

#endif // TEST7_H
