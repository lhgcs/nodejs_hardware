﻿#include <QCoreApplication>

#include "test1.h"
#include "test2.h"
#include "test3.h"
#include "test4.h"
#include "test5.h"
#include "test6.h"
#include "test7.h"

int main(int argc, char *argv[])
{
    test6();
}

