#ifndef TEST6_H
#define TEST6_H


void test6();

#endif // TEST6_H
