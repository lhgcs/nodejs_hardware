#ifndef TEST1_H
#define TEST1_H


void test1();

#endif // TEST1_H
