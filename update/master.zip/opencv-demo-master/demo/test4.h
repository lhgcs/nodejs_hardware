#ifndef TEST4_H
#define TEST4_H


void test4();

#endif // TEST4_H
