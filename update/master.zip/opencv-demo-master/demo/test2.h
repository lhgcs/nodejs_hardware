#ifndef TEST2_H
#define TEST2_H



void test2();


#endif // TEST2_H
